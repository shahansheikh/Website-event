    import React from 'react';

const Schedule = () => {
    return (
        <div className="schedule">
            <h2>10:00 AM</h2>
            <p>Opening Remarks</p>
            <h2>10:30 AM</h2>
            <p>Keynote Speech by [Andrew]</p>
            <h2>11:30 AM</h2>
            <p>Panel Discussion: [marketing strategies]</p>
            <h2>12:30 PM</h2>
            <p>Lunch Break</p>
            <h2>1:30 PM</h2>
            <p>Workshop: [AI in Marketing]</p>
            <h2>3:00 PM</h2>
            <p>Coffee Break</p>
            <h2>3:30 PM</h2>
            <p>Closing Keynote: [Andrew]</p>
            <h2>4:30 PM</h2>
            <p>Networking Session</p>
        </div>
    );
}
    