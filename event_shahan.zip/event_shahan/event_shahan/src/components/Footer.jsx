import React from "react";

const Footer = () => {
    return (
        <footer>
            <p>&copy; 2023 Event Shahan. All rights reserved.</p>
            <p>Contact us: <a href="mailto:info@eventshahan.com">info@eventshahan.com</a></p>
            <h2>Organizer's Name</h2>
            <p>Event is organized by [Andrew], dedicated to creating memorable events.</p>
            <h2>Email</h2>
            <p><a href="mailto:info@eventshahan.com">info@eventshahan.com</a></p>
        </footer>
    );
}

export default Footer;
