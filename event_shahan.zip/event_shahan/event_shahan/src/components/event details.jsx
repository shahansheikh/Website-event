import React from "react";

const EventDetails = () => {
    return (
        <div className="event-details">
            <h2>Event Details</h2>
            <p>The event will take place on [2/15/2024] at [Mumbai].</p>
            <h2>[Event Purpose]</h2>
            <p>This event aims to [bring together professionals from various fields to network and share knowledge].</p>
            <h2>[Event Theme]</h2>
            <p>The theme of the event is [Innovation and Collaboration in the Modern World].</p>
            <h2>[Event Description]</h2>
            <p>This event will feature keynote speakers, panel discussions, and networking opportunities.</p>
            <h2>[Highlights]</h2>
            <p>Key highlights include [interactive workshops, expert panels, and a closing gala].</p>
        </div>
    );
};

export default EventDetails;
